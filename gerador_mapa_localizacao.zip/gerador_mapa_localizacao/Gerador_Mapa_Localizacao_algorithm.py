# -*- coding: utf-8 -*- 
"""
Mapa formatado (Vetor 1/2 + Raster) — QGIS 3.40
- A4 (retrato), mapa = metade da página
- Extensão auto-ajustada à razão do item
- SEM legenda automática; legendas MANUAIS (LEGENDA_RASTER_TXT, LEGENDA_V1_TXT, LEGENDA_V2_TXT)
- Ícones: raster (gradiente), vetores (patch por tipo e cor)
- Rodapé ao lado das legendas (abaixo do eixo X)
- Barra de escala funcional (comprimento/altura ajustáveis)
- Grid só para linhas; rótulos X no topo e Y à esquerda
"""

from qgis.core import (
    Qgis, QgsProject, QgsProcessing, QgsProcessingAlgorithm, QgsProcessingException,
    QgsProcessingParameterVectorLayer, QgsProcessingParameterRasterLayer,
    QgsProcessingParameterString, QgsProcessingParameterNumber, QgsProcessingParameterEnum,
    QgsProcessingParameterBoolean, QgsProcessingParameterFileDestination, QgsProcessingParameterColor,
    QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsRectangle, QgsWkbTypes,
    QgsLineSymbol, QgsFillSymbol, QgsMarkerSymbol, QgsSingleSymbolRenderer,
    QgsPrintLayout, QgsLayoutItemMap, QgsLayoutSize, QgsLayoutPoint, QgsUnitTypes,
    QgsLayoutItemScaleBar, QgsLayoutItemLabel, QgsLayoutItemMapGrid, QgsLayoutItemPicture,
    QgsLayoutExporter, QgsRasterLayer,
)
from qgis.PyQt.QtGui import QFont, QColor, QImage, QPainter, QPen, QBrush, QLinearGradient, QPolygonF
from qgis.PyQt.QtCore import Qt, QRectF, QPointF
import tempfile, os, math


class Gerador_Mapa_LocalizacaoAlgorithm(QgsProcessingAlgorithm):
    V1='VETOR_1'; V2='VETOR_2'; RST='RASTER'
    COR_V1='COR_CONTORNO_1'; COR_V2='COR_CONTORNO_2'
    ESP_LINHA='ESPESSURA_LINHA'; OPACIDADE='OPACIDADE'
    AJ_X='AJUSTE_ENQ_X'; AJ_Y='AJUSTE_ENQ_Y'
    FONTE_COORD='TAM_FONTE_COORD'; EST_ESCALA='ESTILO_ESCALA'
    TITULO='TITULO'; SUBTITULO='SUBTITULO'; RODAPE='TEXTO_RODAPE'
    ADD_BASE='ADD_BASEMAP'; SAIDA='ARQUIVO_SAIDA'; DPI='DPI'
    LEG_RASTER_TXT='LEGENDA_RASTER_TXT'; LEG_V1_TXT='LEGENDA_V1_TXT'; LEG_V2_TXT='LEGENDA_V2_TXT'
    MARG_Y='MARG_ROTULO_Y_MM'; MARG_X='MARG_ROTULO_X_MM'
    ENQ_Y='ENQ_ROTULO_Y'; ENQ_X='ENQ_ROTULO_X'

    # Barra de escala
    SB_W = 'SB_LARGURA_TOTAL_MM'
    SB_H = 'SB_ALTURA_MM'
    SB_UNIT = 'SB_UNIDADE'      # km/m
    SB_FONT = 'SB_FONTE_PT'     # fonte dos rótulos (EXTREMIDADES)

    def name(self): return 'mapa_a4_meia_pagina_legenda_manual_qgis340_v7'
    def displayName(self): return 'Mapa A4 (meia página, legenda manual) — PDF/PNG'
    def group(self): return 'Cartografia (A4/Auto-fit)'
    def groupId(self): return 'cartografia_a4_autofit'
    def createInstance(self): return Gerador_Mapa_LocalizacaoAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterVectorLayer(self.V1,'Camada vetorial 1 (obrigatória)',[QgsProcessing.TypeVectorAnyGeometry]))
        self.addParameter(QgsProcessingParameterVectorLayer(self.V2,'Camada vetorial 2 (opcional)',[QgsProcessing.TypeVectorAnyGeometry],optional=True))
        self.addParameter(QgsProcessingParameterRasterLayer(self.RST,'Camada raster (opcional)',optional=True))
        self.addParameter(QgsProcessingParameterColor(self.COR_V1,'Cor contorno Vetor 1',defaultValue=QColor('#1f77b4')))
        self.addParameter(QgsProcessingParameterColor(self.COR_V2,'Cor contorno Vetor 2',defaultValue=QColor('#d62728')))
        self.addParameter(QgsProcessingParameterNumber(self.ESP_LINHA,'Espessura da linha (pt)',type=QgsProcessingParameterNumber.Double,defaultValue=0.6,minValue=0.1))
        self.addParameter(QgsProcessingParameterNumber(self.OPACIDADE,'Opacidade [0–1]',type=QgsProcessingParameterNumber.Double,defaultValue=0.9,minValue=0.0,maxValue=1.0))
        self.addParameter(QgsProcessingParameterNumber(self.AJ_X,'Ajuste_enquadramento_X (m)',type=QgsProcessingParameterNumber.Double,defaultValue=1000.0,minValue=0.0))
        self.addParameter(QgsProcessingParameterNumber(self.AJ_Y,'Ajuste_enquadramento_Y (m)',type=QgsProcessingParameterNumber.Double,defaultValue=1000.0,minValue=0.0))
        self.addParameter(QgsProcessingParameterNumber(self.FONTE_COORD,'Tamanho da fonte das coordenadas (pt)',type=QgsProcessingParameterNumber.Integer,defaultValue=10))
        self.addParameter(QgsProcessingParameterEnum(self.EST_ESCALA,'Estilo da barra de escala',options=['barra','ticks'],defaultValue=0))
        self.addParameter(QgsProcessingParameterString(self.TITULO,'Título',defaultValue='Título do Mapa'))
        self.addParameter(QgsProcessingParameterString(self.SUBTITULO,'Subtítulo',defaultValue='Subtítulo do Mapa'))
        self.addParameter(QgsProcessingParameterString(self.RODAPE,'Texto de rodapé (use \\n para quebras)',defaultValue='Sistema de Coordenadas: SIRGAS 2000 / Web Mercator (EPSG:3857)\\nAutor: —\\nData: —'))
        self.addParameter(QgsProcessingParameterString(self.LEG_RASTER_TXT,'Legenda do Raster (opcional)',defaultValue='',optional=True))
        self.addParameter(QgsProcessingParameterString(self.LEG_V1_TXT,'Legenda do Vetor 1 (opcional)',defaultValue='',optional=True))
        self.addParameter(QgsProcessingParameterString(self.LEG_V2_TXT,'Legenda do Vetor 2 (opcional)',defaultValue='',optional=True))
        self.addParameter(QgsProcessingParameterBoolean(self.ADD_BASE,'Adicionar basemap OSM (XYZ) [opcional]',defaultValue=False))
        self.addParameter(QgsProcessingParameterFileDestination(self.SAIDA,'Arquivo de saída (PDF ou PNG)',fileFilter='PDF (*.pdf);;PNG (*.png)'))
        self.addParameter(QgsProcessingParameterNumber(self.DPI,'DPI para PNG',type=QgsProcessingParameterNumber.Integer,defaultValue=300))
        # margens / enquadramento dos eixos
        self.addParameter(QgsProcessingParameterNumber(self.MARG_Y,'Margem externa dos rótulos Y (mm)',type=QgsProcessingParameterNumber.Double,defaultValue=7.0))
        self.addParameter(QgsProcessingParameterNumber(self.MARG_X,'Margem externa dos rótulos X (mm)',type=QgsProcessingParameterNumber.Double,defaultValue=0.0))
        self.addParameter(QgsProcessingParameterEnum(self.ENQ_Y,'Enquadramento rótulos Y',options=['Fora da moldura','Dentro da moldura'],defaultValue=0))
        self.addParameter(QgsProcessingParameterEnum(self.ENQ_X,'Enquadramento rótulos X',options=['Dentro da moldura','Fora da moldura'],defaultValue=0))
        # barra de escala
        self.addParameter(QgsProcessingParameterNumber(self.SB_W,'Comprimento total da barra de escala (mm)',type=QgsProcessingParameterNumber.Double,defaultValue=30.0,minValue=10.0))
        self.addParameter(QgsProcessingParameterNumber(self.SB_H,'Altura da barra de escala (mm)',type=QgsProcessingParameterNumber.Double,defaultValue=6.0,minValue=2.0))
        self.addParameter(QgsProcessingParameterEnum(self.SB_UNIT,'Unidade da barra de escala',options=['Quilômetros (km)','Metros (m)'],defaultValue=0))
        self.addParameter(QgsProcessingParameterNumber(self.SB_FONT,'Tamanho da fonte da barra de escala (pt)',type=QgsProcessingParameterNumber.Integer,defaultValue=8,minValue=6,maxValue=24))

    # ---------- utils ----------
    def _nice_step(self, span):
        if span<=0: return 1.0
        raw=span/6.0; exp=math.floor(math.log10(raw)); base=raw/(10**exp)
        nice=1 if base<=1 else 2 if base<=2 else 5 if base<=5 else 10
        return nice*(10**exp)

    def _fmt_end_value(self, v):
        s = f"{v:.6g}"
        if '.' in s: s = s.rstrip('0').rstrip('.')
        return s

    def _style_vector(self, vlyr, color, width_pt, opacity):
        g=vlyr.geometryType()
        if g==QgsWkbTypes.PointGeometry:
            sym=QgsMarkerSymbol.createSimple({'color':color.name(),'size':'2.2'})
        elif g==QgsWkbTypes.LineGeometry:
            sym=QgsLineSymbol.createSimple({'color':color.name(),'width':str(width_pt)})
        else:
            sym=QgsFillSymbol.createSimple({'outline_color':color.name(),'outline_width':str(width_pt),'color':'0,0,0,0'})
        vlyr.setRenderer(QgsSingleSymbolRenderer(sym))
        try: vlyr.setOpacity(float(opacity))
        except: pass

    def _union_extent_3857(self, layers):
        proj=QgsProject.instance(); tgt=QgsCoordinateReferenceSystem('EPSG:3857')
        rect=None
        for lyr in layers:
            if not lyr: continue
            src=lyr.crs()
            if not src.isValid(): continue
            tr=QgsCoordinateTransform(src,tgt,proj)
            try: r=tr.transformBoundingBox(lyr.extent())
            except: continue
            rect=QgsRectangle(r) if rect is None else rect.combineExtentWith(r) or rect
        if rect is None: raise QgsProcessingException('Não foi possível calcular a extensão combinada.')
        return rect

    def _expand_to_aspect(self, rect, target_aspect):
        w=rect.width(); h=rect.height()
        if w<=0 or h<=0: return rect
        aspect=w/h
        if abs(aspect-target_aspect)<1e-6: return QgsRectangle(rect)
        if aspect<target_aspect:
            new_w=h*target_aspect; dx=(new_w-w)/2.0
            return QgsRectangle(rect.xMinimum()-dx,rect.yMinimum(),rect.xMaximum()+dx,rect.yMaximum())
        else:
            new_h=w/target_aspect; dy=(new_h-h)/2.0
            return QgsRectangle(rect.xMinimum(),rect.yMinimum()-dy,rect.xMaximum(),rect.yMaximum()+dy)

    # ícones
    def _tmp_png(self,prefix='ico'):
        fd,path=tempfile.mkstemp(prefix=prefix+'_',suffix='.png'); os.close(fd); return path

    def _icon_raster_gradient(self,w=120,h=22):
        path=self._tmp_png('raster'); img=QImage(w,h,QImage.Format_ARGB32); img.fill(Qt.transparent)
        p=QPainter(img)
        try:
            grad=QLinearGradient(0,0,w,0)
            grad.setColorAt(0.00,QColor(68,1,84)); grad.setColorAt(0.25,QColor(59,82,139))
            grad.setColorAt(0.50,QColor(33,145,140)); grad.setColorAt(0.75,QColor(94,201,98)); grad.setColorAt(1.00,QColor(253,231,37))
            p.setBrush(QBrush(grad)); p.setPen(QPen(Qt.black,1)); p.drawRect(QRectF(1,1,w-2,h-2))
        finally: p.end()
        img.save(path,'PNG'); return path

    def _icon_vector_patch(self,geom_type,color,w=120,h=22):
        path=self._tmp_png('vetor'); img=QImage(w,h,QImage.Format_ARGB32); img.fill(Qt.transparent)
        p=QPainter(img)
        try:
            pen=QPen(color,3,Qt.SolidLine,Qt.RoundCap,Qt.RoundJoin)
            if geom_type==QgsWkbTypes.PointGeometry:
                p.setPen(Qt.NoPen); p.setBrush(QBrush(color)); r=min(w,h)*0.35; p.drawEllipse(int(w*0.5-r/2),int(h*0.5-r/2),int(r),int(r))
            elif geom_type==QgsWkbTypes.LineGeometry:
                p.setPen(pen); y=h/2; p.drawLine(8,int(y),w-8,int(y))
            else:
                p.setPen(QPen(color,3)); p.setBrush(Qt.NoBrush); p.drawRect(QRectF(6,4,w-12,h-8))
        finally: p.end()
        img.save(path,'PNG'); return path

    # >>>>>> NOVO: gera um pequeno ícone de Norte geográfico (PNG temporário) <<<<<<
    def _icon_north_arrow(self, w=120, h=120):
        path = self._tmp_png('north')
        img = QImage(w, h, QImage.Format_ARGB32)
        img.fill(Qt.transparent)
        p = QPainter(img)
        try:
            p.setRenderHint(QPainter.Antialiasing, True)
            # seta/triângulo (preto)
            pen = QPen(Qt.black, max(2, int(w*0.03)), Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin)
            p.setPen(pen); p.setBrush(QBrush(Qt.black))
            cx = w/2.0; top = h*0.12; base_y = h*0.50; half = w*0.18
            poly = QPolygonF([QPointF(cx, top), QPointF(cx-half, base_y), QPointF(cx+half, base_y)])
            p.drawPolygon(poly)
            # haste
            shaft_w = w*0.08; shaft_h = h*0.30
            p.drawRect(QRectF(cx - shaft_w/2.0, base_y, shaft_w, shaft_h))
            # letra N
            p.setPen(QPen(Qt.black, max(1, int(w*0.02))))
            p.setFont(QFont('Arial', max(8, int(h*0.18))))
            p.drawText(QRectF(0, h*0.72, w, h*0.22), Qt.AlignHCenter | Qt.AlignVCenter, 'N')
        finally:
            p.end()
        img.save(path, 'PNG')
        return path

    def _fit_label_one_line(self, lbl, base_pt, max_width_mm, min_pt=7):
        try: lbl.setWordWrapEnabled(False)
        except: pass
        lbl.setText(lbl.text().replace('\n',' '))
        size=int(base_pt)
        while size>=min_pt:
            f=QFont('Arial',size); lbl.setFont(f); lbl.adjustSizeToText()
            if lbl.sizeWithUnits().width()<=max_width_mm: break
            size-=1
        return size

    # ===== rótulos Y (VERTICAIS) — SOMENTE À ESQUERDA =====
    def _add_vertical_y_labels(self, layout, extent, step_y, font_pt,
                               m_left, m_top, map_h_mm, map_w_mm,
                               marg_y_mm, enq_y_outside=True):
        ymin = extent.yMinimum(); ymax = extent.yMaximum()
        if step_y <= 0 or ymax <= ymin: return
        start = math.ceil(ymin/step_y) * step_y
        end   = math.floor(ymax/step_y) * step_y
        yval = start
        fmt = lambda v: f"{v:.3f}"
        INNER_MM = float(marg_y_mm) if (not enq_y_outside and marg_y_mm>0) else 2.5
        OUTER_MM = float(marg_y_mm)
        while yval <= end + 1e-9:
            if abs(yval - ymin) < 1e-9 or abs(yval - ymax) < 1e-9:
                yval += step_y; continue
            t = (yval - ymin) / (ymax - ymin)
            y_mm = m_top + (1.0 - t) * map_h_mm
            lbl = QgsLayoutItemLabel(layout)
            lbl.setText(fmt(yval))
            lbl.setFont(QFont('Arial', font_pt))
            lbl.setHAlign(Qt.AlignHCenter); lbl.setVAlign(Qt.AlignVCenter)
            lbl.adjustSizeToText(); layout.addLayoutItem(lbl)
            try:
                from qgis.core import QgsLayoutItem
                lbl.setReferencePoint(QgsLayoutItem.ReferencePoint.Center)
            except Exception: pass
            bbox = lbl.sizeWithUnits()
            half_rotated_width = bbox.height() / 2.0
            if enq_y_outside:
                pad = half_rotated_width + OUTER_MM; x_mm = m_left - pad; angle = -90.0
            else:
                pad = half_rotated_width + INNER_MM; x_mm = m_left + pad; angle = -90.0
            lbl.attemptMove(QgsLayoutPoint(x_mm, y_mm, QgsUnitTypes.LayoutMillimeters))
            try: lbl.setItemRotation(angle)
            except Exception:
                try: lbl.setRotation(angle)
                except Exception: pass
            yval += step_y

    # ===== rótulos X (HORIZONTAIS) — SOMENTE NO TOPO =====
    def _add_horizontal_x_labels(self, layout, extent, step_x, font_pt,
                                 m_left, m_top, map_w_mm, map_h_mm,
                                 marg_x_mm, enq_x_outside=False):
        xmin=extent.xMinimum(); xmax=extent.xMaximum()
        if step_x<=0 or xmax<=xmin: return
        if enq_x_outside:  # topo fora
            y_top = m_top - float(marg_x_mm if marg_x_mm>0 else 4.0)
        else:
            inner = float(marg_x_mm if marg_x_mm>0 else 2.5)
            y_top = m_top + inner
        start = math.ceil(xmin/step_x)*step_x
        end   = math.floor(xmax/step_x)*step_x
        xval = start; fmt = lambda v: f"{v:.3f}"
        while xval <= end + 1e-9:
            if abs(xval-xmin)<1e-9 or abs(xval-xmax)<1e-9:
                xval += step_x; continue
            t = (xval - xmin)/(xmax - xmin)
            x_mm = m_left + t * map_w_mm
            lbl = QgsLayoutItemLabel(layout)
            lbl.setText(fmt(xval)); lbl.setFont(QFont('Arial', font_pt))
            lbl.setHAlign(Qt.AlignHCenter); lbl.setVAlign(Qt.AlignVCenter)
            lbl.adjustSizeToText(); layout.addLayoutItem(lbl)
            try:
                from qgis.core import QgsLayoutItem
                lbl.setReferencePoint(QgsLayoutItem.ReferencePoint.Center)
            except Exception: pass
            lbl.attemptMove(QgsLayoutPoint(x_mm, y_top, QgsUnitTypes.LayoutMillimeters))
            xval += step_x

    # ---------- core ----------
    def processAlgorithm(self, parameters, context, feedback):
        if Qgis.QGIS_VERSION_INT < 34000:
            raise QgsProcessingException('Requer QGIS ≥ 3.40.')

        proj=QgsProject.instance()
        v1=self.parameterAsVectorLayer(parameters,self.V1,context)
        v2=self.parameterAsVectorLayer(parameters,self.V2,context)
        rst=self.parameterAsRasterLayer(parameters,self.RST,context)
        if not v1 or not v1.isValid(): raise QgsProcessingException('Camada Vetorial 1 inválida.')

        cor1=self.parameterAsColor(parameters,self.COR_V1,context)
        cor2=self.parameterAsColor(parameters,self.COR_V2,context)
        esp=self.parameterAsDouble(parameters,self.ESP_LINHA,context)
        opa=self.parameterAsDouble(parameters,self.OPACIDADE,context)
        ajx=self.parameterAsDouble(parameters,self.AJ_X,context)
        ajy=self.parameterAsDouble(parameters,self.AJ_Y,context)
        fcoord=int(self.parameterAsInt(parameters,self.FONTE_COORD,context))
        est_esc=int(self.parameterAsEnum(parameters,self.EST_ESCALA,context))
        titulo=self.parameterAsString(parameters,self.TITULO,context)
        subtit=self.parameterAsString(parameters,self.SUBTITULO,context)
        rodape=self.parameterAsString(parameters,self.RODAPE,context).replace('\\n','\n')
        leg_raster_txt=self.parameterAsString(parameters,self.LEG_RASTER_TXT,context) if parameters.get(self.LEG_RASTER_TXT) is not None else ''
        leg_v1_txt=self.parameterAsString(parameters,self.LEG_V1_TXT,context) if parameters.get(self.LEG_V1_TXT) is not None else ''
        leg_v2_txt=self.parameterAsString(parameters,self.LEG_V2_TXT,context) if parameters.get(self.LEG_V2_TXT) is not None else ''
        add_base=self.parameterAsBool(parameters,self.ADD_BASE,context)
        out_path=self.parameterAsFileOutput(parameters,self.SAIDA,context)
        dpi=int(self.parameterAsInt(parameters,self.DPI,context))
        marg_y=float(self.parameterAsDouble(parameters,self.MARG_Y,context))
        marg_x=float(self.parameterAsDouble(parameters,self.MARG_X,context))
        enq_y_outside = (int(self.parameterAsEnum(parameters,self.ENQ_Y,context)) == 0)
        enq_x_outside = (int(self.parameterAsEnum(parameters,self.ENQ_X,context)) == 1)

        # tamanho da barra de escala
        sb_total_mm = float(self.parameterAsDouble(parameters, self.SB_W, context))
        sb_height_mm = float(self.parameterAsDouble(parameters, self.SB_H, context))
        if sb_total_mm <= 0: sb_total_mm = 30.0
        if sb_height_mm <= 0: sb_height_mm = 6.0

        # unidade e fonte dos rótulos (EXTREMIDADES)
        sb_unit_idx = int(self.parameterAsEnum(parameters, self.SB_UNIT, context))
        if sb_unit_idx == 0:
            sb_units = QgsUnitTypes.DistanceKilometers; sb_label = 'km'
        else:
            sb_units = QgsUnitTypes.DistanceMeters; sb_label = 'm'
        sb_font_pt = int(self.parameterAsInt(parameters, self.SB_FONT, context))

        # estilo vetores
        self._style_vector(v1,cor1,esp,opa)
        if v2: self._style_vector(v2,cor2,esp,opa)

        # extent + ajustes
        ext=self._union_extent_3857([v1,v2,rst])
        ext=QgsRectangle(ext.xMinimum()-ajx,ext.yMinimum()-ajy,ext.xMaximum()+ajx,ext.yMaximum()+ajy)

        # layout A4
        layout=QgsPrintLayout(proj); layout.initializeDefaults()
        page=layout.pageCollection().pages()[0]
        page.setPageSize(QgsLayoutSize(210,297,QgsUnitTypes.LayoutMillimeters))
        page_size=page.pageSize()
        layout.setName('Gerador_Mapa_LocalizacaoAlgorithm')

        # margens / área do mapa
        M_LEFT, M_RIGHT, M_TOP, M_BOTTOM = 24.0, 24.0, 25.0, 26.0
        usable_w=max(50.0,page_size.width()-(M_LEFT+M_RIGHT))
        usable_h=max(50.0,page_size.height()-(M_TOP+M_BOTTOM))
        MAP_FRAC_H=0.50
        map_w_mm=usable_w
        map_h_mm=max(50.0,usable_h*MAP_FRAC_H)

        # mapa
        map_item=QgsLayoutItemMap(layout)
        map_item.setCrs(QgsCoordinateReferenceSystem('EPSG:3857'))
        map_item.attemptMove(QgsLayoutPoint(M_LEFT,M_TOP,QgsUnitTypes.LayoutMillimeters))
        map_item.attemptResize(QgsLayoutSize(map_w_mm,map_h_mm,QgsUnitTypes.LayoutMillimeters))
        map_item.setFrameEnabled(True)

        # ---------------- CAMADAS (forçar vetores no topo) ----------------
        base_layers=[]; raster_layers=[]; vector_layers=[]
        if add_base:
            try:
                url="type=xyz&url=https://tile.openstreetmap.org/{z}/{x}/{y}.png&zmin=0&zmax=19"
                osm=QgsRasterLayer(url,"OSM","wms")
                if not osm.isValid(): osm=QgsRasterLayer(url,"OSM","gdal")
                if osm and osm.isValid():
                    QgsProject.instance().addMapLayer(osm,False)
                    base_layers.append(osm)
            except: pass
        if rst: raster_layers.append(rst)
        if v1: vector_layers.append(v1)
        if v2: vector_layers.append(v2)

        # Ordem ajustada: VETORES → RASTER → BASE
        # e manter essa pilha fixa no item de mapa
        layer_stack = vector_layers + raster_layers + base_layers
        map_item.setLayers(layer_stack)
        try:
            map_item.setKeepLayerSet(True)  # garante que o item use exatamente esta pilha/ordem
        except Exception:
            pass
        # ------------------------------------------------------------------

        # auto-fit
        target_aspect=map_w_mm/map_h_mm
        ext2=self._expand_to_aspect(ext,target_aspect)
        map_item.setExtent(ext2)
        layout.addLayoutItem(map_item)

        # >>>>>> NOVO: Norte geográfico (pequeno, canto superior direito do MAPA) <<<<<<
        na_path = self._icon_north_arrow(120, 120)  # gera PNG temporário
        north = QgsLayoutItemPicture(layout)
        north.setPicturePath(na_path)
        N_W, N_H = 8.0, 12.0  # tamanho pequeno (mm)
        north.attemptResize(QgsLayoutSize(N_W, N_H, QgsUnitTypes.LayoutMillimeters))
        north.attemptMove(QgsLayoutPoint(M_LEFT + map_w_mm - N_W - 2.0,
                                         M_TOP + 2.0,
                                         QgsUnitTypes.LayoutMillimeters))
        layout.addLayoutItem(north)
        # ---------------------------------------------------------------

        # GRID
        grid = QgsLayoutItemMapGrid('grid', map_item)
        grid.setCrs(QgsCoordinateReferenceSystem('EPSG:3857'))
        step_x = self._nice_step(ext2.width()); step_y = self._nice_step(ext2.height())
        try: grid.setIntervalX(step_x); grid.setIntervalY(step_y)
        except Exception:
            try: grid.setGridIntervalX(step_x); grid.setGridIntervalY(step_y)
            except Exception: pass
        grid.setEnabled(True)
        try: grid.setAnnotationEnabled(False)
        except Exception: pass
        try: map_item.grids().addGrid(grid)
        except Exception: pass

        # RÓTULOS DOS EIXOS
        self._add_horizontal_x_labels(layout, ext2, step_x, fcoord, M_LEFT, M_TOP, map_w_mm, map_h_mm, marg_x, enq_x_outside)
        self._add_vertical_y_labels(layout,   ext2, step_y, fcoord, M_LEFT, M_TOP, map_h_mm, map_w_mm, marg_y, enq_y_outside)

        # TÍTULO / SUBTÍTULO
        lbl_title=QgsLayoutItemLabel(layout); lbl_title.setText(titulo); lbl_title.setFont(QFont('Arial',14)); lbl_title.adjustSizeToText()
        layout.addLayoutItem(lbl_title)
        maxw=page_size.width()-20; self._fit_label_one_line(lbl_title,14,maxw,8)
        tw=lbl_title.sizeWithUnits().width()
        lbl_title.attemptMove(QgsLayoutPoint((page_size.width()-tw)/2,6,QgsUnitTypes.LayoutMillimeters))
        lbl_sub=QgsLayoutItemLabel(layout); lbl_sub.setText(subtit.replace('\n',' ')); lbl_sub.setFont(QFont('Arial',8)); lbl_sub.adjustSizeToText()
        layout.addLayoutItem(lbl_sub)
        sw=lbl_sub.sizeWithUnits().width()
        lbl_sub.attemptMove(QgsLayoutPoint((page_size.width()-sw)/2,12.5,QgsUnitTypes.LayoutMillimeters))

        # LEGENDAS + RODAPÉ
        base_y=M_TOP+map_h_mm+4.0
        left_col_w=map_w_mm*0.55; right_col_w=map_w_mm-left_col_w-4.0
        cur_y=base_y; row_h=7.0; icon_w=18.0; icon_h=6.0
        def add_row_icon_text(icon_path,text):
            nonlocal cur_y
            pic=QgsLayoutItemPicture(layout); pic.setPicturePath(icon_path)
            pic.attemptMove(QgsLayoutPoint(M_LEFT,cur_y,QgsUnitTypes.LayoutMillimeters))
            pic.attemptResize(QgsLayoutSize(icon_w,icon_h,QgsUnitTypes.LayoutMillimeters)); layout.addLayoutItem(pic)
            lbl=QgsLayoutItemLabel(layout); lbl.setText(text); lbl.setFont(QFont('Arial',8)); lbl.setHAlign(Qt.AlignLeft); layout.addLayoutItem(lbl)
            lbl.attemptMove(QgsLayoutPoint(M_LEFT+icon_w+2.0,cur_y-0.5,QgsUnitTypes.LayoutMillimeters))
            lbl.attemptResize(QgsLayoutSize(left_col_w-icon_w-2.0,row_h+2.0,QgsUnitTypes.LayoutMillimeters))
            cur_y+=row_h
        if leg_raster_txt.strip(): add_row_icon_text(self._icon_raster_gradient(),leg_raster_txt.strip())
        if leg_v1_txt.strip():     add_row_icon_text(self._icon_vector_patch(v1.geometryType(),cor1),leg_v1_txt.strip())
        if v2 and leg_v2_txt.strip(): add_row_icon_text(self._icon_vector_patch(v2.geometryType(),cor2),leg_v2_txt.strip())
        lbl_cap=QgsLayoutItemLabel(layout); lbl_cap.setText(rodape); lbl_cap.setFont(QFont('Arial',8)); lbl_cap.setHAlign(Qt.AlignLeft); layout.addLayoutItem(lbl_cap)
        lbl_cap.attemptMove(QgsLayoutPoint(M_LEFT+left_col_w+4.0,base_y,QgsUnitTypes.LayoutMillimeters))
        lbl_cap.attemptResize(QgsLayoutSize(right_col_w,max(row_h*3,28),QgsUnitTypes.LayoutMillimeters))

        # ===== Barra de escala (rótulos apenas nas extremidades) =====
        scalebar=QgsLayoutItemScaleBar(layout)
        scalebar.setLinkedMap(map_item)
        scalebar.applyDefaultSize()
        scalebar.setUnits(sb_units)
        scalebar.setStyle('Single Box' if est_esc==0 else 'Line Ticks Middle')

        # ocultar totalmente rótulos internos
        scalebar.setUnitLabel('')
        try: scalebar.setFontColor(QColor(0,0,0,0))
        except Exception: pass
        scalebar.setFont(QFont('Arial', 1))

        # Segmentos e altura
        scalebar.setNumberOfSegments(4)
        scalebar.setNumberOfSegmentsLeft(0)
        scalebar.setHeight(sb_height_mm)

        # Espaços
        try: scalebar.setLabelBarSpace(2.0)
        except Exception: pass
        try: scalebar.setBoxContentSpace(1.0)
        except Exception: pass

        # Largura da barra + padding do ITEM
        PAD_W_MM = 20.0 + max(0.0, (sb_font_pt - 8) * 1.5)
        PAD_H_MM = max(6.0, sb_font_pt * 1.8)
        try:
            from qgis.core import QgsScaleBarSettings
            scalebar.setSegmentSizeMode(QgsScaleBarSettings.SegmentSizeMode.FitWidth)
            try:
                scalebar.setMinimumBarWidth(sb_total_mm)
                scalebar.setMaximumBarWidth(sb_total_mm)
            except Exception: pass
        except Exception:
            scalebar.attemptResize(QgsLayoutSize(sb_total_mm, sb_height_mm, QgsUnitTypes.LayoutMillimeters))
        scalebar.attemptResize(QgsLayoutSize(sb_total_mm + PAD_W_MM, sb_height_mm + PAD_H_MM, QgsUnitTypes.LayoutMillimeters))
        layout.addLayoutItem(scalebar)

        # Posicionar item
        sb_y=max(cur_y,base_y+16.0)
        sb_x=M_LEFT+left_col_w+4.0
        scalebar.attemptMove(QgsLayoutPoint(sb_x,sb_y,QgsUnitTypes.LayoutMillimeters))
        try: scalebar.refresh()
        except: pass

        # --- valor total e rótulos das extremidades ---
        try: units_per_seg = float(scalebar.unitsPerSegment())
        except Exception: units_per_seg = None
        try: nseg = int(scalebar.numberOfSegments())
        except Exception: nseg = 4
        total_val = units_per_seg * nseg if (units_per_seg and units_per_seg > 0) else None
        right_text = (f"{total_val:.1f} {sb_label}" if total_val is not None else f"{nseg} {sb_label}")

        # Posições aproximadas
        left_mm  = sb_x + 1.0
        right_mm = sb_x + sb_total_mm - 1.0
        label_y  = sb_y - 0.8

        def _add_end_label(txt, x_mm):
            lbl = QgsLayoutItemLabel(layout)
            lbl.setText(txt)
            lbl.setFont(QFont('Arial', sb_font_pt))
            lbl.setHAlign(Qt.AlignHCenter); lbl.setVAlign(Qt.AlignBottom)
            lbl.adjustSizeToText(); layout.addLayoutItem(lbl)
            try:
                from qgis.core import QgsLayoutItem
                lbl.setReferencePoint(QgsLayoutItem.ReferencePoint.Center)
            except Exception: pass
            lbl.attemptMove(QgsLayoutPoint(x_mm, label_y, QgsUnitTypes.LayoutMillimeters))

        _add_end_label("0", left_mm)
        _add_end_label(right_text, right_mm)

        # Eixos X/Y
        lx=QgsLayoutItemLabel(layout); lx.setText('X (E)'); lx.setFont(QFont('Arial',9)); lx.adjustSizeToText()
        layout.addLayoutItem(lx)
        lx.attemptMove(QgsLayoutPoint(M_LEFT+map_w_mm/2-8,M_TOP+map_h_mm+1.5,QgsUnitTypes.LayoutMillimeters))
        ly=QgsLayoutItemLabel(layout); ly.setText('Y (N)'); ly.setFont(QFont('Arial',9)); ly.adjustSizeToText()
        layout.addLayoutItem(ly)
        ly.attemptMove(QgsLayoutPoint(M_LEFT-10, M_TOP-5, QgsUnitTypes.LayoutMillimeters))

        # Export
        exporter=QgsLayoutExporter(layout)
        if out_path.lower().endswith('.pdf'):
            res=exporter.exportToPdf(out_path,QgsLayoutExporter.PdfExportSettings())
        else:
            img=QgsLayoutExporter.ImageExportSettings(); img.dpi=dpi
            res=exporter.exportToImage(out_path,img)
        if res!=QgsLayoutExporter.Success: raise QgsProcessingException('Falha ao exportar mapa.')
        return { self.SAIDA: out_path }

    def shortHelpString(self):
        return (
            "Gera automaticamente um mapa em formato A4 (retrato, meia página) "
            "a partir de até duas camadas vetoriais e uma raster. "
            "A extensão do mapa é ajustada à área das camadas de entrada, "
            "com moldura, coordenadas e barra de escala configuráveis.\n\n"
            "⚙️ Parâmetros principais:\n"
            "• Camada Vetorial 1 – obrigatória.\n"
            "• Camada Vetorial 2 – opcional.\n"
            "• Camada Raster – opcional.\n"
            "• Cores e espessura dos contornos das camadas vetoriais.\n"
            "• Ajustes de enquadramento (X e Y, em metros).\n"
            "• Tamanho da fonte das coordenadas e estilo da barra de escala.\n"
            "• Título, subtítulo e rodapé personalizáveis.\n"
            "• Legendas manuais (texto) para raster, vetor 1 e vetor 2.\n"
            "• Opção para adicionar mapa base (OpenStreetMap XYZ).\n"
            "• Saída em arquivo PDF ou PNG com DPI definido.\n\n"
            "🧭 Funcionalidades adicionais:\n"
            "• Adiciona automaticamente seta de norte.\n"
            "• Cria barras de escala proporcionais (km ou m) com rótulos nas extremidades.\n"
            "• Insere eixos X/Y com rótulos e grades customizadas.\n\n"
            "💡 Observações:\n"
            "• O layout é exportado automaticamente sem necessidade de edição manual.\n"
            "• Desenvolvido para QGIS ≥ 3.40.\n"
        )
    def helpUrl(self):
        return 'https://drive.google.com/file/d/1UZvnP6aWvJ3AlVN908LaGC_2ZqjOcjLe/view?usp=sharing'

def classFactory():
    return Gerador_Mapa_LocalizacaoAlgorithm()

